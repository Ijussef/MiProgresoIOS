import UIKit

var saludo = "Hola mundo"

print(saludo)

// Luis_Jussef_Gonzalez_Medel



let string = ["azul", "verde", "rojo", "amarillo"]

let tieneHambre = true
let noTieneDinero = false

let edad = 18

var entero = 10
var _dinero = 250
var x_cuadrada = 8
var variable = 23.1


let miNombre: String = Luis
let miApellido: String = Gonzalez
let miEdad: entero = 18


